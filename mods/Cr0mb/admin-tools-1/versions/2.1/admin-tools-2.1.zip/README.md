# Admin Tools 2.1 (a Jester mod)

A window for everything the console can do, plus controls for the other players on a server, so you never need to remember a command.

**Works with:** Jester 1.14.0 and later for the panel. On 1.13.0 the console commands work without it. On 1.11.0 and 1.12.0 only the older shortcuts work (build, daylight, calm,
kit, tour, lift, scout, fast, where, watch, release, lockdown, open); the `admin` switches and the player controls need 1.13.0.

**Install:** in the Jester Launcher, open *Mods*, then *Browse*, and press *Install* on Admin Tools. Or choose *Add a
mod* and pick `AdminTools.zip`, or unzip it so that `%APPDATA%\JesterGame\mods\AdminTools\data\macros.json` exists.

**Use:** press the crown button beside the tools, at the bottom right of the screen. You can give it a key in *Settings > Controls*, or type `panel` in the console. Everything below can also be typed: `admin help` lists it.

## The panel

The world keeps going behind it, so a switch shows its effect at once. Drag it by its title bar. Esc closes it.

| Tab | What is there |
| --- | --- |
| **You** | every switch, damage, speed, defence, health, mana, level, talent points, coins, xp, buffs, and your mods' shortcuts |
| **World** | time, weather, kill aura, frozen creatures, see through walls, zoom, spawning, and every creature to spawn |
| **Items** | search every item, choose how many and click to give it, to yourself or the player chosen on the Players tab |
| **Places** | every named place, one click away, or click the world to go there |
| **Players** | online: choose a player or everyone, then heal, cure, give, bring, go to, mute, freeze, undo their last 10 minutes, kick, ban or make operator; who may cheat, grief alerts, bans, protected areas, backups |
| **Console** | every command, what it does, and a search; click one to run it or fill it in; the log of what happened |

Right click any control to pin it to the top row (up to six). Dangerous ones (kick, ban, emptying a pack) ask first. The bottom of the panel shows what is on, the last reply, and *Turn all off*.

## Who can use it

- **Single player:** anyone. The first time, the game warns you and asks you to agree. From then on, feats
  (achievements) are off for that character for good. Admin Tools can lock feats but never unlock them.
- **Online:** only the host and the server's operators, whatever the server's `cheats` setting says. Someone who stops
  being an operator loses every switch at once. The server checks too: only an operator's command makes it act on
  another player, a player's game can't fake one, and items, gold and moves the server didn't see earned are taken back.

## Switches: `admin <name> [value]` (the same again turns it off)

| Switch | What it does |
| --- | --- |
| `infhp`, `infmana`, `infbreath` | health, mana and breath never run down |
| `nofall`, `quickrespawn`, `nodebuffs` | no fall damage, back on your feet at once, no ailments |
| `infjumps`, `infflight` | endless air jumps, endless flight from wings and capes |
| `onehit`, `killaura [range]`, `freezemobs` | one blow kills, creatures near you fall, creatures stand still |
| `nocooldowns`, `rapid` | spells, potions, dash and cape ready at once; fast swings and shots |
| `infitems`, `vacuum`, `instamine` | stacks never shrink, drops fly to you, blocks break in one hit |
| `freezetime [hour]`, `fullbright`, `zoom <x>`, `esp` | stop the clock, light everywhere, zoom in or out, creatures boxed through walls |
| `dmg <x>`, `movespeed <x>`, `def <n>`, `hp <n>`, `mana <n>` | damage and speed multipliers, defence, health and mana bonuses |
| `admin`, `admin off` | what is on, everything off |

## Commands

| Command | What it does |
| --- | --- |
| `setstat hp\|mana\|gold\|xp\|level\|perks\|breath <n>` | set any number |
| `buff <id> [secs]`, `unbuff <id>`, `buffs`, `clearbuffs`, `forget <spell>` | buffs and spells |
| `tpcursor`, `tpspawn`, `nudge <dx> <dy>` | move about (with the built-in `tp`, `fly` and `noclip`) |
| `slot <area> <i> <item> [n]`, `swap`, `clearslot`, `count`, `ench`, `enchants` | any inventory or equipment slot (areas: inv, armor, acc, gear, wear, pet) |
| `maxstacks`, `dupe`, `pullall`, `clearpack [all]`, `sortpack` | items |
| `despawn`, `bringmobs` | clear or gather creatures (with the built-in `spawn` and `killall`) |
| `feats lock <id>`, `feats lockall` | lock feats again |

## Other players (online, operators)

| Command | What it does |
| --- | --- |
| `player <name\|all> heal` / `kill` / `god on\|off` | heal, strike down, make unhurtable |
| `player <name\|all> give <item> [n]` / `gold <amount>` / `xp <n>` | give items, gold or xp (the server's books agree) |
| `player <name\|all> buff <id> [secs]` / `cleanse` / `clearpack` | buffs, lift ailments, empty a pack |
| `player <name\|all> tp <x> <y>`, `bring <name\|all>`, `goto <name>` | move players, or go to one |
| `player <name> info` | health, place, purse and ping |

Every use is logged on the server and told to its operators.

## Shortcuts this mod adds

`immortal`, `berserk`, `miner`, `seer`, `hoard`, `sprint <x>`, `stopall`, and for servers `healall`, `gatherall`,
`smite <name>`, `gift <name> <item> [n]`, `purse <name> <amount>` and `check <name>`, as well as the older ones
(`build`, `daylight`, `nightfall`, `calm`, `wild`, `patch`, `kit`, `tour`, `lift`, `scout`, `fast`, `where`, `watch`,
`release`, `lockdown`, `open`). Type `help` to see them all.

**Safe by design:** a Jester mod holds only pictures (PNG), sounds (WAV/OGG) and tables (JSON/TXT). This one is a single
JSON file; the switches live in the game itself. The game never runs anything from a mod folder, and the launcher
refuses mods holding programs or scripts.
